# Campus TicTac 🎮

A production-ready, mobile-first Tic-Tac-Toe application tailored for college students. Featuring neon aesthetics, real-time multiplayer, and AI opponents.

![GitHub Actions](https://img.shields.io/github/actions/workflow/status/YOUR_USERNAME/YOUR_REPO/deploy.yml?branch=main&label=Deploy&style=flat-square)
![License](https://img.shields.io/github/license/YOUR_USERNAME/YOUR_REPO?style=flat-square)

## 🚀 Features

- **AI Mode**: Play against a smart AI with 3 difficulty levels (Minimax Algorithm).
- **Online Multiplayer**: Real-time duels via Firebase.
- **Local Multiplayer**: Play with a friend on the same device.
- **Leaderboards**: Global, College-specific, and Weekly rankings.
- **Customizable Boards**: 3x3, 4x4, and 5x5 grids.

## 🛠️ Tech Stack

- **Frontend**: React, Tailwind CSS, Framer Motion, Lucide React.
- **Backend**: Firebase (Auth, Firestore, Realtime Database).
- **Deployment**: GitHub Pages / Netlify.

## 📦 Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file based on `.env.example` and add your Firebase credentials.
4. Start the development server:
   ```bash
   npm run dev
   ```

## 🌐 Deployment

### GitHub Pages
This project is configured for automated deployment via GitHub Actions.
1. Go to your repository **Settings** > **Secrets and variables** > **Actions**.
2. Add your Firebase credentials as **Secrets** (e.g., `VITE_FIREBASE_API_KEY`).
3. Push to the `main` branch, and the app will deploy automatically.

### Netlify
1. Connect your repository to Netlify.
2. Add the environment variables in the Netlify dashboard.
3. Deploy!

## 📄 License
MIT
