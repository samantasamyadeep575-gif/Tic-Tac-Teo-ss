import { Player } from '../types';

export const checkWinner = (board: Player[], size: number) => {
  const winCount = size === 3 ? 3 : size === 4 ? 4 : 5;

  // Helper to check a line
  const checkLine = (indices: number[]) => {
    if (indices.length < winCount) return null;
    
    for (let i = 0; i <= indices.length - winCount; i++) {
      const slice = indices.slice(i, i + winCount);
      const first = board[slice[0]];
      if (first && slice.every(idx => board[idx] === first)) {
        return { winner: first, line: slice };
      }
    }
    return null;
  };

  // Rows
  for (let r = 0; r < size; r++) {
    const row = [];
    for (let c = 0; c < size; c++) row.push(r * size + c);
    const result = checkLine(row);
    if (result) return result;
  }

  // Columns
  for (let c = 0; c < size; c++) {
    const col = [];
    for (let r = 0; r < size; r++) col.push(r * size + c);
    const result = checkLine(col);
    if (result) return result;
  }

  // Diagonals (top-left to bottom-right)
  // We need to check all possible diagonals that can fit winCount
  for (let r = 0; r <= size - winCount; r++) {
    for (let c = 0; c <= size - winCount; c++) {
      const diag = [];
      for (let i = 0; i < winCount; i++) diag.push((r + i) * size + (c + i));
      const result = checkLine(diag);
      if (result) return result;
    }
  }

  // Diagonals (top-right to bottom-left)
  for (let r = 0; r <= size - winCount; r++) {
    for (let c = winCount - 1; c < size; c++) {
      const diag = [];
      for (let i = 0; i < winCount; i++) diag.push((r + i) * size + (c - i));
      const result = checkLine(diag);
      if (result) return result;
    }
  }

  return null;
};

export const getBestMove = (board: Player[], size: number, difficulty: 'easy' | 'medium' | 'hard'): number => {
  const availableMoves = board.map((val, idx) => val === null ? idx : null).filter(val => val !== null) as number[];
  
  if (difficulty === 'easy') {
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
  }

  // Basic strategy for Medium
  if (difficulty === 'medium') {
    // 1. Can I win?
    for (const move of availableMoves) {
      const tempBoard = [...board];
      tempBoard[move] = 'O';
      if (checkWinner(tempBoard, size)) return move;
    }
    // 2. Can I block?
    for (const move of availableMoves) {
      const tempBoard = [...board];
      tempBoard[move] = 'X';
      if (checkWinner(tempBoard, size)) return move;
    }
    // 3. Random
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
  }

  // Minimax for Hard (limited depth for larger boards to avoid lag)
  const maxDepth = size === 3 ? 9 : size === 4 ? 4 : 3;
  
  const minimax = (tempBoard: Player[], depth: number, isMaximizing: boolean, alpha: number, beta: number): number => {
    const result = checkWinner(tempBoard, size);
    if (result?.winner === 'O') return 10 - depth;
    if (result?.winner === 'X') return depth - 10;
    if (tempBoard.every(cell => cell !== null) || depth >= maxDepth) return 0;

    if (isMaximizing) {
      let bestScore = -Infinity;
      for (let i = 0; i < tempBoard.length; i++) {
        if (tempBoard[i] === null) {
          tempBoard[i] = 'O';
          const score = minimax(tempBoard, depth + 1, false, alpha, beta);
          tempBoard[i] = null;
          bestScore = Math.max(score, bestScore);
          alpha = Math.max(alpha, score);
          if (beta <= alpha) break;
        }
      }
      return bestScore;
    } else {
      let bestScore = Infinity;
      for (let i = 0; i < tempBoard.length; i++) {
        if (tempBoard[i] === null) {
          tempBoard[i] = 'X';
          const score = minimax(tempBoard, depth + 1, true, alpha, beta);
          tempBoard[i] = null;
          bestScore = Math.min(score, bestScore);
          beta = Math.min(beta, score);
          if (beta <= alpha) break;
        }
      }
      return bestScore;
    }
  };

  let bestScore = -Infinity;
  let move = -1;
  const tempBoard = [...board];
  
  for (let i = 0; i < tempBoard.length; i++) {
    if (tempBoard[i] === null) {
      tempBoard[i] = 'O';
      const score = minimax(tempBoard, 0, false, -Infinity, Infinity);
      tempBoard[i] = null;
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  
  return move === -1 ? availableMoves[0] : move;
};
