export type Player = 'X' | 'O' | null;

export interface GameState {
  board: Player[];
  size: number;
  isXNext: boolean;
  winner: Player;
  winningLine: number[] | null;
  isDraw: boolean;
}

export interface UserProfile {
  uid: string;
  username: string;
  email: string;
  photoURL: string;
  college: string;
  department?: string;
  stats: {
    wins: number;
    losses: number;
    draws: number;
    totalMatches: number;
  };
  rank: string;
  createdAt: number;
}

export interface Room {
  id: string;
  hostId: string;
  hostName: string;
  opponentId: string | null;
  opponentName: string | null;
  status: 'waiting' | 'playing' | 'finished';
  board: Player[];
  size: number;
  isXNext: boolean;
  winner: Player;
  winningLine: number[] | null;
  rematchRequested: { [key: string]: boolean };
}
