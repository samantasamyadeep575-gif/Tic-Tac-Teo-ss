import { useState, useEffect } from 'react';
import { ref, onValue, set, update, onDisconnect, remove } from 'firebase/database';
import { rtdb } from '../services/firebase';
import { Player, Room } from '../types';
import { checkWinner } from '../utils/gameLogic';
import confetti from 'canvas-confetti';

export const useOnlineGame = (roomId: string | null, userId: string | null, userName: string | null) => {
  const [room, setRoom] = useState<Room | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!roomId || !rtdb) return;

    const roomRef = ref(rtdb, `rooms/${roomId}`);
    const unsubscribe = onValue(roomRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setRoom(data);
      } else {
        setRoom(null);
      }
    });

    return () => unsubscribe();
  }, [roomId]);

  const createRoom = async (size: number) => {
    if (!userId || !userName || !rtdb) return null;
    setLoading(true);
    const id = Math.random().toString(36).substring(2, 8).toUpperCase();
    const newRoom: Room = {
      id,
      hostId: userId,
      hostName: userName,
      opponentId: null,
      opponentName: null,
      status: 'waiting',
      board: Array(size * size).fill(null),
      size,
      isXNext: true,
      winner: null,
      winningLine: null,
      rematchRequested: {},
    };

    try {
      await set(ref(rtdb, `rooms/${id}`), newRoom);
      onDisconnect(ref(rtdb, `rooms/${id}`)).remove();
      setLoading(false);
      return id;
    } catch (err) {
      setError('Failed to create room');
      setLoading(false);
      return null;
    }
  };

  const joinRoom = async (id: string) => {
    if (!userId || !userName || !rtdb) return false;
    setLoading(true);
    try {
      const roomRef = ref(rtdb, `rooms/${id}`);
      const snapshot = await new Promise<any>((resolve) => onValue(roomRef, (s) => resolve(s), { onlyOnce: true }));
      const data = snapshot.val();

      if (!data) {
        setError('Room not found');
        setLoading(false);
        return false;
      }

      if (data.opponentId && data.opponentId !== userId) {
        setError('Room is full');
        setLoading(false);
        return false;
      }

      if (data.hostId === userId) {
        setLoading(false);
        return true;
      }

      await update(roomRef, {
        opponentId: userId,
        opponentName: userName,
        status: 'playing',
      });

      setLoading(false);
      return true;
    } catch (err) {
      setError('Failed to join room');
      setLoading(false);
      return false;
    }
  };

  const makeMove = async (index: number) => {
    if (!room || room.status !== 'playing' || room.winner || room.board[index] || !rtdb) return;

    const isHost = userId === room.hostId;
    const myTurn = (isHost && room.isXNext) || (!isHost && !room.isXNext);

    if (!myTurn) return;

    const newBoard = [...room.board];
    newBoard[index] = isHost ? 'X' : 'O';

    const result = checkWinner(newBoard, room.size);
    const updates: any = {
      board: newBoard,
      isXNext: !room.isXNext,
    };

    if (result) {
      updates.winner = result.winner;
      updates.winningLine = result.line;
      updates.status = 'finished';
      confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });
    } else if (newBoard.every(cell => cell !== null)) {
      updates.status = 'finished';
    }

    await update(ref(rtdb, `rooms/${room.id}`), updates);
  };

  const requestRematch = async () => {
    if (!room || !userId || !rtdb) return;
    const updates: any = {
      [`rematchRequested/${userId}`]: true,
    };

    const otherUserId = userId === room.hostId ? room.opponentId : room.hostId;
    if (room.rematchRequested[otherUserId!]) {
      // Both agreed, reset game
      updates.board = Array(room.size * room.size).fill(null);
      updates.isXNext = true;
      updates.winner = null;
      updates.winningLine = null;
      updates.status = 'playing';
      updates.rematchRequested = {};
    }

    await update(ref(rtdb, `rooms/${room.id}`), updates);
  };

  const leaveRoom = async () => {
    if (!room || !userId || !rtdb) return;
    if (room.hostId === userId) {
      await remove(ref(rtdb, `rooms/${room.id}`));
    } else {
      await update(ref(rtdb, `rooms/${room.id}`), {
        opponentId: null,
        opponentName: null,
        status: 'waiting',
      });
    }
  };

  return { room, loading, error, createRoom, joinRoom, makeMove, requestRematch, leaveRoom };
};
