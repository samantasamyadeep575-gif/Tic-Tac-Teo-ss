import React from 'react';
import { motion } from 'motion/react';
import { Player } from '../types';
import { cn } from '../utils/cn';

interface BoardProps {
  board: Player[];
  size: number;
  onSquareClick: (index: number) => void;
  winningLine: number[] | null;
  disabled?: boolean;
}

export const Board: React.FC<BoardProps> = ({ board, size, onSquareClick, winningLine, disabled }) => {
  const gridCols = {
    3: 'grid-cols-3',
    4: 'grid-cols-4',
    5: 'grid-cols-5',
  }[size] || 'grid-cols-3';

  return (
    <div className={cn('grid gap-2 w-full max-w-[400px] aspect-square', gridCols)}>
      {board.map((square, i) => {
        const isWinningSquare = winningLine?.includes(i);
        
        return (
          <motion.button
            key={i}
            whileHover={!disabled && !square ? { scale: 1.05, backgroundColor: 'rgba(255,255,255,0.1)' } : {}}
            whileTap={!disabled && !square ? { scale: 0.95 } : {}}
            onClick={() => onSquareClick(i)}
            disabled={disabled || !!square}
            className={cn(
              'glass-panel flex items-center justify-center text-3xl sm:text-4xl font-black transition-all duration-300',
              !square && !disabled && 'cursor-pointer hover:border-primary/50',
              isWinningSquare && 'bg-accent/20 border-accent text-accent neon-glow-accent',
              square === 'X' && !isWinningSquare && 'text-primary',
              square === 'O' && !isWinningSquare && 'text-white'
            )}
          >
            {square && (
              <motion.span
                initial={{ scale: 0, rotate: -45 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              >
                {square}
              </motion.span>
            )}
          </motion.button>
        );
      })}
    </div>
  );
};
