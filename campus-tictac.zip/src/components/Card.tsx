import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../utils/cn';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
}

export const Card: React.FC<CardProps> = ({ children, className, glow }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'glass-panel p-6',
        glow && 'neon-glow',
        className
      )}
    >
      {children}
    </motion.div>
  );
};
