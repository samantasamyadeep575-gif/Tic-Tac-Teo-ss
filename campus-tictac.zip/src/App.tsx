import React, { useState, useEffect } from 'react';
import { LogIn, Trophy, Users, User as UserIcon, Gamepad2, Globe, School, Flame, Share2, Copy, Check } from 'lucide-react';
import { useAuth } from './hooks/useAuth';
import { useOnlineGame } from './hooks/useOnlineGame';
import { Button } from './components/Button';
import { Card } from './components/Card';
import { Board } from './components/Board';
import { checkWinner, getBestMove } from './utils/gameLogic';
import { Player, GameState } from './types';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';
import { auth, googleProvider, db, isConfigured } from './services/firebase';
import { signInWithPopup, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc, increment, collection, query, orderBy, limit, getDocs, where } from 'firebase/firestore';
import { cn } from './utils/cn';
import { AlertTriangle } from 'lucide-react';

type View = 'home' | 'ai-setup' | 'game-ai' | 'local-setup' | 'game-local' | 'online-lobby' | 'game-online' | 'leaderboard' | 'profile' | 'auth';

export default function App() {
  const { user, profile, loading, refreshProfile } = useAuth();
  const [view, setView] = useState<View>('home');
  const [gameState, setGameState] = useState<GameState>({
    board: Array(9).fill(null),
    size: 3,
    isXNext: true,
    winner: null,
    winningLine: null,
    isDraw: false,
  });
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [boardSize, setBoardSize] = useState<number>(3);
  const [leaderboardTab, setLeaderboardTab] = useState<'global' | 'college' | 'weekly'>('global');
  const [leaderboardData, setLeaderboardData] = useState<any[]>([]);
  const [authLoading, setAuthLoading] = useState(false);
  const [signupData, setSignupData] = useState({ college: '', username: '' });
  
  const [currentRoomId, setCurrentRoomId] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState('');
  const [copied, setCopied] = useState(false);

  const { 
    room, 
    loading: onlineLoading, 
    error: onlineError, 
    createRoom, 
    joinRoom, 
    makeMove: makeOnlineMove, 
    requestRematch, 
    leaveRoom 
  } = useOnlineGame(currentRoomId, user?.uid || null, profile?.username || null);

  // AI Game Logic
  const handleAISquareClick = (index: number) => {
    if (gameState.board[index] || gameState.winner || gameState.isDraw || !gameState.isXNext) return;

    const newBoard = [...gameState.board];
    newBoard[index] = 'X';
    
    const result = checkWinner(newBoard, gameState.size);
    if (result) {
      setGameState({ ...gameState, board: newBoard, winner: result.winner, winningLine: result.line });
      confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });
      updateStats(result.winner === 'X' ? 'win' : 'loss');
      return;
    }

    if (newBoard.every(cell => cell !== null)) {
      setGameState({ ...gameState, board: newBoard, isDraw: true });
      updateStats('draw');
      return;
    }

    setGameState({ ...gameState, board: newBoard, isXNext: false });

    // AI Move
    setTimeout(() => {
      const aiMove = getBestMove(newBoard, gameState.size, difficulty);
      const aiBoard = [...newBoard];
      aiBoard[aiMove] = 'O';
      
      const aiResult = checkWinner(aiBoard, gameState.size);
      if (aiResult) {
        setGameState({ ...gameState, board: aiBoard, winner: aiResult.winner, winningLine: aiResult.line, isXNext: true });
        updateStats(aiResult.winner === 'X' ? 'win' : 'loss');
      } else if (aiBoard.every(cell => cell !== null)) {
        setGameState({ ...gameState, board: aiBoard, isDraw: true, isXNext: true });
        updateStats('draw');
      } else {
        setGameState({ ...gameState, board: aiBoard, isXNext: true });
      }
    }, 600);
  };

  // Local Game Logic
  const handleLocalSquareClick = (index: number) => {
    if (gameState.board[index] || gameState.winner || gameState.isDraw) return;

    const newBoard = [...gameState.board];
    newBoard[index] = gameState.isXNext ? 'X' : 'O';
    
    const result = checkWinner(newBoard, gameState.size);
    if (result) {
      setGameState({ ...gameState, board: newBoard, winner: result.winner, winningLine: result.line });
      confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });
      return;
    }

    if (newBoard.every(cell => cell !== null)) {
      setGameState({ ...gameState, board: newBoard, isDraw: true });
      return;
    }

    setGameState({ ...gameState, board: newBoard, isXNext: !gameState.isXNext });
  };

  const updateStats = async (result: 'win' | 'loss' | 'draw') => {
    if (!user || !profile) return;
    const userRef = doc(db, 'users', user.uid);
    await updateDoc(userRef, {
      'stats.totalMatches': increment(1),
      [`stats.${result}s`]: increment(1),
    });
    refreshProfile();
  };

  const handleGoogleLogin = async () => {
    setAuthLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      if (!userDoc.exists()) {
        setView('auth');
      } else {
        setView('home');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!user || !signupData.college || !signupData.username) return;
    setAuthLoading(true);
    try {
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        username: signupData.username,
        email: user.email,
        photoURL: user.photoURL,
        college: signupData.college,
        stats: { wins: 0, losses: 0, draws: 0, totalMatches: 0 },
        rank: 'Rookie',
        createdAt: Date.now(),
      });
      await refreshProfile();
      setView('home');
    } catch (error) {
      console.error(error);
    } finally {
      setAuthLoading(false);
    }
  };

  const fetchLeaderboard = async (tab: 'global' | 'college' | 'weekly') => {
    setLeaderboardTab(tab);
    let q;
    if (tab === 'global') {
      q = query(collection(db, 'users'), orderBy('stats.wins', 'desc'), limit(20));
    } else if (tab === 'college' && profile) {
      q = query(collection(db, 'users'), where('college', '==', profile.college), orderBy('stats.wins', 'desc'), limit(20));
    } else {
      q = query(collection(db, 'users'), orderBy('stats.wins', 'desc'), limit(20));
    }
    const querySnapshot = await getDocs(q);
    setLeaderboardData(querySnapshot.docs.map(doc => doc.data()));
  };

  const handleCreateRoom = async () => {
    const id = await createRoom(boardSize);
    if (id) {
      setCurrentRoomId(id);
      setView('game-online');
    }
  };

  const handleJoinRoom = async () => {
    const success = await joinRoom(joinCode.toUpperCase());
    if (success) {
      setCurrentRoomId(joinCode.toUpperCase());
      setView('game-online');
    }
  };

  const copyRoomCode = () => {
    if (currentRoomId) {
      navigator.clipboard.writeText(currentRoomId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  useEffect(() => {
    if (room?.status === 'finished' && room.winner) {
      const isHost = user?.uid === room.hostId;
      const result = room.winner === (isHost ? 'X' : 'O') ? 'win' : 'loss';
      updateStats(result);
    }
  }, [room?.status]);

  if (loading) return <div className="flex items-center justify-center h-screen"><div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="min-h-screen flex flex-col items-center p-4 max-w-md mx-auto">
      {!isConfigured && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full mb-6 p-4 glass-panel border-yellow-500/50 flex items-start gap-3 text-sm"
        >
          <AlertTriangle className="w-5 h-5 text-yellow-500 shrink-0" />
          <div className="space-y-1">
            <p className="font-bold text-yellow-500">Firebase Not Configured</p>
            <p className="text-white/60">Please set your Firebase API keys in the environment variables to enable Online Multiplayer and Leaderboards.</p>
          </div>
        </motion.div>
      )}
      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-8 pt-12">
            <div className="text-center space-y-2">
              <h1 className="text-5xl font-black italic tracking-tighter text-primary">CAMPUS</h1>
              <h1 className="text-5xl font-black italic tracking-tighter text-white">TICTAC</h1>
              <p className="text-white/50 font-medium uppercase tracking-widest text-xs">The Ultimate College Duel</p>
            </div>

            <div className="grid gap-4">
              <Button fullWidth size="lg" onClick={() => setView('ai-setup')} className="justify-between">
                <div className="flex items-center gap-3">
                  <Gamepad2 className="w-6 h-6" />
                  <span>VS COMPUTER</span>
                </div>
                <div className="text-xs bg-white/20 px-2 py-1 rounded uppercase">Solo</div>
              </Button>

              <Button fullWidth size="lg" variant="accent" onClick={() => {
                if (!user) handleGoogleLogin();
                else setView('online-lobby');
              }} className="justify-between">
                <div className="flex items-center gap-3">
                  <Globe className="w-6 h-6" />
                  <span>ONLINE MULTIPLAYER</span>
                </div>
                <div className="text-xs bg-navy-900/20 px-2 py-1 rounded uppercase">Live</div>
              </Button>

              <Button fullWidth size="lg" variant="outline" onClick={() => setView('local-setup')} className="justify-between">
                <div className="flex items-center gap-3">
                  <Users className="w-6 h-6" />
                  <span>LOCAL MULTIPLAYER</span>
                </div>
                <div className="text-xs bg-primary/10 px-2 py-1 rounded uppercase">1v1</div>
              </Button>

              <div className="grid grid-cols-2 gap-4">
                <Button variant="ghost" onClick={() => { setView('leaderboard'); fetchLeaderboard('global'); }} className="glass-panel">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  <span>RANKING</span>
                </Button>
                <Button variant="ghost" onClick={() => setView('profile')} className="glass-panel">
                  <UserIcon className="w-5 h-5 text-primary" />
                  <span>PROFILE</span>
                </Button>
              </div>
            </div>

            {!user && (
              <Button fullWidth variant="outline" onClick={handleGoogleLogin} isLoading={authLoading}>
                <LogIn className="w-5 h-5" />
                SIGN IN WITH GOOGLE
              </Button>
            )}
          </motion.div>
        )}

        {(view === 'ai-setup' || view === 'local-setup') && (
          <motion.div key="setup" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="w-full space-y-6 pt-12">
            <Card className="space-y-6">
              <h2 className="text-2xl font-bold text-center">GAME SETUP</h2>
              
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase text-white/50">Board Size</label>
                <div className="grid grid-cols-3 gap-2">
                  {[3, 4, 5].map(s => (
                    <button
                      key={s}
                      onClick={() => setBoardSize(s)}
                      className={cn("p-3 rounded-xl border-2 transition-all", boardSize === s ? "border-primary bg-primary/20" : "border-white/10 bg-white/5")}
                    >
                      {s}x{s}
                    </button>
                  ))}
                </div>
              </div>

              {view === 'ai-setup' && (
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase text-white/50">Difficulty</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['easy', 'medium', 'hard'] as const).map(d => (
                      <button
                        key={d}
                        onClick={() => setDifficulty(d)}
                        className={cn("p-3 rounded-xl border-2 transition-all capitalize", difficulty === d ? "border-accent bg-accent/20 text-accent" : "border-white/10 bg-white/5")}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <Button
                fullWidth
                size="lg"
                onClick={() => {
                  setGameState({
                    board: Array(boardSize * boardSize).fill(null),
                    size: boardSize,
                    isXNext: true,
                    winner: null,
                    winningLine: null,
                    isDraw: false,
                  });
                  setView(view === 'ai-setup' ? 'game-ai' : 'game-local');
                }}
              >
                START GAME
              </Button>
              <Button fullWidth variant="ghost" onClick={() => setView('home')}>BACK</Button>
            </Card>
          </motion.div>
        )}

        {(view === 'game-ai' || view === 'game-local') && (
          <motion.div key="game" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-8 pt-8 flex flex-col items-center">
            <div className="w-full flex justify-between items-center px-2">
              <div className={cn("flex flex-col items-center p-3 rounded-2xl glass-panel w-24 transition-all", gameState.isXNext && "neon-glow border-primary")}>
                <span className="text-xs font-bold text-white/50 uppercase">Player X</span>
                <span className="text-2xl font-black text-primary truncate w-full text-center">{profile?.username?.slice(0, 8) || 'X'}</span>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-black italic text-white/20">VS</h3>
              </div>
              <div className={cn("flex flex-col items-center p-3 rounded-2xl glass-panel w-24 transition-all", !gameState.isXNext && "neon-glow-accent border-accent")}>
                <span className="text-xs font-bold text-white/50 uppercase">{view === 'game-ai' ? 'CPU' : 'Player O'}</span>
                <span className="text-2xl font-black text-accent">{view === 'game-ai' ? 'AI' : 'O'}</span>
              </div>
            </div>

            <Board
              board={gameState.board}
              size={gameState.size}
              onSquareClick={view === 'game-ai' ? handleAISquareClick : handleLocalSquareClick}
              winningLine={gameState.winningLine}
              disabled={!!gameState.winner || gameState.isDraw}
            />

            <div className="w-full space-y-4">
              {gameState.winner && (
                <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="text-center p-4 glass-panel neon-glow-accent">
                  <h2 className="text-3xl font-black text-accent">{gameState.winner === 'X' ? 'VICTORY!' : 'DEFEAT!'}</h2>
                  <p className="text-white/50">Player {gameState.winner} wins the duel</p>
                </motion.div>
              )}
              {gameState.isDraw && (
                <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="text-center p-4 glass-panel">
                  <h2 className="text-3xl font-black text-white/50">DRAW</h2>
                  <p className="text-white/50">A perfect stalemate</p>
                </motion.div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <Button fullWidth variant="outline" onClick={() => setGameState({ ...gameState, board: Array(gameState.size * gameState.size).fill(null), winner: null, winningLine: null, isDraw: false, isXNext: true })}>RESTART</Button>
                <Button fullWidth variant="ghost" onClick={() => setView('home')}>EXIT</Button>
              </div>
            </div>
          </motion.div>
        )}

        {view === 'game-online' && (
          <motion.div key="game-online" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-8 pt-8 flex flex-col items-center">
            {room?.status === 'waiting' ? (
              <Card className="w-full text-center space-y-6">
                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto neon-glow">
                  <Users className="w-10 h-10 text-primary animate-pulse" />
                </div>
                <h2 className="text-2xl font-black italic">WAITING FOR OPPONENT</h2>
                <div className="space-y-2">
                  <p className="text-white/50 text-xs uppercase font-bold">Room Code</p>
                  <div className="flex items-center justify-center gap-2 bg-white/5 p-4 rounded-xl border border-white/10">
                    <span className="text-3xl font-black tracking-widest text-primary">{room.id}</span>
                    <button onClick={copyRoomCode} className="p-2 hover:bg-white/10 rounded-lg transition-all">
                      {copied ? <Check className="w-5 h-5 text-accent" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
                <Button fullWidth variant="ghost" onClick={async () => { await leaveRoom(); setView('home'); }}>CANCEL</Button>
              </Card>
            ) : room ? (
              <>
                <div className="w-full flex justify-between items-center px-2">
                  <div className={cn("flex flex-col items-center p-3 rounded-2xl glass-panel w-28 transition-all", room.isXNext && "neon-glow border-primary")}>
                    <span className="text-[10px] font-bold text-white/50 uppercase">Player X</span>
                    <span className="text-sm font-black text-primary truncate w-full text-center">{room.hostName}</span>
                  </div>
                  <div className="text-center">
                    <h3 className="text-xl font-black italic text-white/20">VS</h3>
                  </div>
                  <div className={cn("flex flex-col items-center p-3 rounded-2xl glass-panel w-28 transition-all", !room.isXNext && "neon-glow-accent border-accent")}>
                    <span className="text-[10px] font-bold text-white/50 uppercase">Player O</span>
                    <span className="text-sm font-black text-accent truncate w-full text-center">{room.opponentName || '...'}</span>
                  </div>
                </div>

                <Board
                  board={room.board}
                  size={room.size}
                  onSquareClick={makeOnlineMove}
                  winningLine={room.winningLine}
                  disabled={room.status !== 'playing' || (user?.uid === room.hostId ? !room.isXNext : room.isXNext)}
                />

                <div className="w-full space-y-4">
                  {room.winner && (
                    <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="text-center p-4 glass-panel neon-glow-accent">
                      <h2 className="text-3xl font-black text-accent">{room.winner === (user?.uid === room.hostId ? 'X' : 'O') ? 'VICTORY!' : 'DEFEAT!'}</h2>
                      <p className="text-white/50">{room.winner === 'X' ? room.hostName : room.opponentName} wins</p>
                    </motion.div>
                  )}
                  {room.status === 'finished' && !room.winner && (
                    <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="text-center p-4 glass-panel">
                      <h2 className="text-3xl font-black text-white/50">DRAW</h2>
                    </motion.div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      fullWidth 
                      variant={room.rematchRequested[user!.uid] ? "outline" : "accent"} 
                      onClick={requestRematch}
                      disabled={room.status !== 'finished' || room.rematchRequested[user!.uid]}
                    >
                      {room.rematchRequested[user!.uid] ? "WAITING..." : "REMATCH"}
                    </Button>
                    <Button fullWidth variant="ghost" onClick={async () => { await leaveRoom(); setView('home'); }}>EXIT</Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4">
                <p>Room closed or connection lost</p>
                <Button onClick={() => setView('home')}>BACK HOME</Button>
              </div>
            )}
          </motion.div>
        )}

        {view === 'leaderboard' && (
          <motion.div key="leaderboard" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="w-full space-y-6 pt-8">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black italic">RANKINGS</h2>
              <Button variant="ghost" size="sm" onClick={() => setView('home')}>BACK</Button>
            </div>

            <div className="flex gap-2 p-1 glass-panel rounded-xl">
              <button onClick={() => fetchLeaderboard('global')} className={cn("flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1", leaderboardTab === 'global' ? "bg-primary text-white" : "text-white/50")}>
                <Globe className="w-3 h-3" /> GLOBAL
              </button>
              <button onClick={() => fetchLeaderboard('college')} className={cn("flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1", leaderboardTab === 'college' ? "bg-primary text-white" : "text-white/50")}>
                <School className="w-3 h-3" /> COLLEGE
              </button>
              <button onClick={() => fetchLeaderboard('weekly')} className={cn("flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1", leaderboardTab === 'weekly' ? "bg-primary text-white" : "text-white/50")}>
                <Flame className="w-3 h-3" /> WEEKLY
              </button>
            </div>

            <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2">
              {leaderboardData.map((p, i) => (
                <div key={p.uid} className={cn("flex items-center gap-4 p-4 glass-panel", p.uid === user?.uid && "border-primary/50 bg-primary/5")}>
                  <div className="w-8 h-8 flex items-center justify-center font-black text-white/20 text-xl italic">{i + 1}</div>
                  <img src={p.photoURL} alt="" className="w-10 h-10 rounded-full border-2 border-white/10" referrerPolicy="no-referrer" />
                  <div className="flex-1">
                    <div className="font-bold">{p.username}</div>
                    <div className="text-[10px] text-white/40 uppercase tracking-tighter">{p.college}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-primary font-black">{p.stats.wins}</div>
                    <div className="text-[10px] text-white/40 uppercase">WINS</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {view === 'profile' && profile && (
          <motion.div key="profile" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="w-full space-y-6 pt-12">
            <Card className="text-center space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-primary/20 to-transparent" />
              <div className="relative pt-4">
                <img src={profile.photoURL} alt="" className="w-24 h-24 rounded-full mx-auto border-4 border-navy-900 neon-glow" referrerPolicy="no-referrer" />
                <h2 className="text-2xl font-black mt-4">{profile.username}</h2>
                <div className="flex items-center justify-center gap-2 text-white/50 text-sm">
                  <School className="w-4 h-4" />
                  <span>{profile.college}</span>
                </div>
                <div className="mt-2 inline-block px-3 py-1 bg-accent/20 text-accent text-xs font-bold rounded-full border border-accent/30 uppercase tracking-widest">
                  {profile.rank}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 border-y border-white/10 py-6">
                <div>
                  <div className="text-2xl font-black text-primary">{profile.stats.wins}</div>
                  <div className="text-[10px] text-white/40 uppercase font-bold">Wins</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-white">{profile.stats.totalMatches}</div>
                  <div className="text-[10px] text-white/40 uppercase font-bold">Played</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-accent">{profile.stats.totalMatches > 0 ? Math.round((profile.stats.wins / profile.stats.totalMatches) * 100) : 0}%</div>
                  <div className="text-[10px] text-white/40 uppercase font-bold">Win Rate</div>
                </div>
              </div>

              <div className="space-y-3">
                <Button fullWidth variant="outline" onClick={() => signOut(auth)}>LOGOUT</Button>
                <Button fullWidth variant="ghost" onClick={() => setView('home')}>BACK</Button>
              </div>
            </Card>
          </motion.div>
        )}

        {view === 'auth' && (
          <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-6 pt-12">
            <Card className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-black italic">JOIN THE CAMPUS</h2>
                <p className="text-white/50 text-sm">Complete your profile to start competing</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-white/50">Username</label>
                  <input
                    type="text"
                    value={signupData.username}
                    onChange={e => setSignupData({ ...signupData, username: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-all"
                    placeholder="Enter gaming tag"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-white/50">College Name</label>
                  <input
                    type="text"
                    value={signupData.college}
                    onChange={e => setSignupData({ ...signupData, college: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-all"
                    placeholder="e.g. Stanford University"
                  />
                </div>
              </div>

              <Button fullWidth size="lg" onClick={handleSignup} isLoading={authLoading} disabled={!signupData.username || !signupData.college}>
                FINALIZE PROFILE
              </Button>
            </Card>
          </motion.div>
        )}

        {view === 'online-lobby' && (
          <motion.div key="online" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-6 pt-12">
             <Card className="text-center space-y-6">
                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto neon-glow">
                  <Globe className="w-10 h-10 text-primary animate-pulse" />
                </div>
                <h2 className="text-2xl font-black italic">ONLINE ARENA</h2>
                <p className="text-white/50 text-sm">Challenge students from across the globe in real-time duels.</p>
                
                <div className="space-y-4">
                  <div className="space-y-3">
                    <label className="text-xs font-bold uppercase text-white/50">Board Size</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[3, 4, 5].map(s => (
                        <button
                          key={s}
                          onClick={() => setBoardSize(s)}
                          className={cn("p-3 rounded-xl border-2 transition-all", boardSize === s ? "border-primary bg-primary/20" : "border-white/10 bg-white/5")}
                        >
                          {s}x{s}
                        </button>
                      ))}
                    </div>
                  </div>
                  <Button fullWidth size="lg" variant="accent" onClick={handleCreateRoom} isLoading={onlineLoading}>CREATE PRIVATE ROOM</Button>
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
                    <div className="relative flex justify-center text-xs uppercase font-bold"><span className="bg-navy-800 px-2 text-white/30">OR</span></div>
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      placeholder="Enter Code" 
                      value={joinCode}
                      onChange={e => setJoinCode(e.target.value.toUpperCase())}
                      className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary uppercase" 
                    />
                    <Button variant="primary" onClick={handleJoinRoom} isLoading={onlineLoading} disabled={!joinCode}>JOIN</Button>
                  </div>
                  {onlineError && <p className="text-red-500 text-xs">{onlineError}</p>}
                </div>

                <Button fullWidth variant="ghost" onClick={() => setView('home')}>BACK</Button>
             </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
